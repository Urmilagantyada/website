import React from 'react';
import './Contact.css';

const Contact = () => {
  return (
    <div className="contact-container">
      <video className="background-video" autoPlay muted loop>
        <source src="https://res.cloudinary.com/dstg58cmo/video/upload/v1724409947/tamrawalkthrough_zfjhm9.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>

      <nav className="navbar navbar-expand-lg">
        <div className="container-fluid">
          <img src="https://res.cloudinary.com/dstg58cmo/image/upload/v1726211359/aeries_mkxjg9.jpg" alt="Logo" className="navbar-logo" />
          <a className="navbar-brand" href="#">Brahmin Sangam Bhavanam</a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav mx-auto">
              <li className="nav-item"><a className="nav-link" href="index.html">Home</a></li>
              <li className="nav-item"><a className="nav-link" href="about.html">About Us</a></li>
              <li className="nav-item"><a className="nav-link" href="membership.html">Membership</a></li>
              <li className="nav-item"><a className="nav-link" href="gallery.html">Gallery</a></li>
              <li className="nav-item"><a className="nav-link active" href="contact.html">Contact Us</a></li>
            </ul>
          </div>
        </div>
      </nav>

      <section className="contact-section container mt-5">
        <h2>Contact Us</h2>
        <p>For inquiries, reach out to us:</p>
        <ul>
          <li>Email: contact@brahminsangam.com</li>
          <li>Phone: +123 456 7890</li>
        </ul>

        <form>
          <div className="mb-3">
            <label htmlFor="name" className="form-label">Name</label>
            <input type="text" className="form-control" id="name" placeholder="Your Name" />
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">Email</label>
            <input type="email" className="form-control" id="email" placeholder="Your Email" />
          </div>
          <div className="mb-3">
            <label htmlFor="message" className="form-label">Message</label>
            <textarea className="form-control" id="message" rows="3" placeholder="Your Message"></textarea>
          </div>
          <button type="submit" className="btn btn-primary">Submit</button>
        </form>
      </section>

      <footer className="footer">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h5>Contact Us</h5>
              <form>
                <div className="mb-3">
                  <label htmlFor="name" className="form-label">Name</label>
                  <input type="text" className="form-control" id="name" placeholder="Your Name" />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email</label>
                  <input type="email" className="form-control" id="email" placeholder="Your Email" />
                </div>
                <div className="mb-3">
                  <label htmlFor="message" className="form-label">Message</label>
                  <textarea className="form-control" id="message" rows="3" placeholder="Your Message"></textarea>
                </div>
                <button type="submit" className="btn btn-primary">Send</button>
              </form>
            </div>

            <div className="col-md-6 text-md-end mt-4 mt-md-0">
              <h5>Our Address</h5>
              <p>Brahmin Sangam Bhavanam<br />123 Temple Street, City Name<br />State, Country 123456</p>
            </div>
          </div>

          <div className="text-center mt-4">
            <p>© 2024 Brahmin Sangam Bhavanam. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Contact;
