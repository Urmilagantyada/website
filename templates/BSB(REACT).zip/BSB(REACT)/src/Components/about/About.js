import React from 'react';
import './About.css';

const About = () => {
  return (
    <div>
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg" style={{ backgroundColor: '#e0f17d', height: '80px' }}>
        <div className="container-fluid">
          <img src="https://res.cloudinary.com/dstg58cmo/image/upload/v1726211359/aeries_mkxjg9.jpg" alt="Logo" style={{ width: '200px', height: '50px', marginRight: '10px' }} />
          <a className="navbar-brand" href="#" style={{ color: '#080122', fontSize: '1.5rem' }}>Brahmin Sangam Bhavanam</a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav mx-auto">
              <li className="nav-item"><a className="nav-link me-3" href="index.html" style={{ color: '#fff' }}>Home</a></li>
              <li className="nav-item"><a className="nav-link me-3" href="about.html" style={{ color: '#fff' }}>About Us</a></li>
              <li className="nav-item"><a className="nav-link me-3" href="membership.html" style={{ color: '#fff' }}>Membership</a></li>
              <li className="nav-item"><a className="nav-link me-3" href="gallery.html" style={{ color: '#fff' }}>Gallery</a></li>
              <li className="nav-item"><a className="nav-link" href="contact.html" style={{ color: '#fff' }}>Contact Us</a></li>
            </ul>
          </div>
        </div>
      </nav>

      {/* About Section */}
      <section className="container mt-5">
        <h2>About Brahmin Sangam Bhavanam</h2>
        <p>Brahmin Sangam Bhavan is an incredible community with 1200+ members. Here, we can help you create wonderful memories and experiences that will last a lifetime.</p>
      </section>

      {/* Reviews Section */}
      <section className="container mt-5">
        <h2 className="mb-4 text-center">5-Star Reviews</h2>
        {[...Array(5)].map((_, i) => (
          <div key={i} className="row my-4 review-container">
            <div className="col-md-2">
              <img src="https://res.cloudinary.com/dstg58cmo/image/upload/v1726556155/5_star_mxrlg0.png" alt={`Reviewer ${i + 1}`} className="img-fluid rounded-circle review-img" />
            </div>
            <div className="col-md-10">
              <h5 className="review-name">{['John Doe', 'Jane Smith', 'Michael Johnson', 'Emily Davis', 'David Wilson'][i]}</h5>
              <p className="review-text">
                {['Brahmin Sangam Bhavanam is an exceptional place. The community and facilities are top-notch, and every event we host here is memorable.',
                'We had an amazing experience at Brahmin Sangam Bhavanam. The staff is friendly, and the services are excellent. I highly recommend it!',
                'This is the best place to organize events. The ambiance is wonderful, and every detail is taken care of to perfection. I give it 5 stars!',
                'Brahmin Sangam Bhavanam exceeded all my expectations. The service was impeccable, and the staff was highly professional. I highly recommend it!',
                'I hosted an event at Brahmin Sangam Bhavanam, and it was an incredible experience. The environment, service, and overall quality were outstanding!'][i]}
              </p>
            </div>
          </div>
        ))}
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="row">
            {/* Left Side: Contact Form */}
            <div className="col-md-6">
              <h5>Contact Us</h5>
              <form>
                <div className="mb-3">
                  <label htmlFor="name" className="form-label">Name</label>
                  <input type="text" className="form-control" id="name" placeholder="Your Name" />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email</label>
                  <input type="email" className="form-control" id="email" placeholder="Your Email" />
                </div>
                <div className="mb-3">
                  <label htmlFor="message" className="form-label">Message</label>
                  <textarea className="form-control" id="message" rows="3" placeholder="Your Message"></textarea>
                </div>
                <button type="submit" className="btn btn-primary">Send</button>
              </form>
            </div>

            {/* Right Side: Address */}
            <div className="col-md-6 text-md-end mt-4 mt-md-0">
              <h5>Our Address</h5>
              <p>Brahmin Sangam Bhavanam<br />123 Temple Street, City Name<br />State, Country 123456</p>
            </div>
          </div>

          {/* Copyright Notice */}
          <div className="text-center mt-4">
            <p>© 2024 Brahmin Sangam Bhavanam. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default About;
