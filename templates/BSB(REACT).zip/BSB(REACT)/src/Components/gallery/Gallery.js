import React, { useState } from 'react';
import './Gallery.css';

const Gallery = () => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const images = [
    "https://res.cloudinary.com/dstg58cmo/image/upload/v1726209897/ww1_vtnswo.jpg",
    "https://res.cloudinary.com/dstg58cmo/image/upload/v1726209981/w3_hab2b6.jpg",
    "https://res.cloudinary.com/dstg58cmo/image/upload/v1726209897/ww1_vtnswo.jpg",
    "https://res.cloudinary.com/dstg58cmo/image/upload/v1726209981/w3_hab2b6.jpg",
    "https://res.cloudinary.com/dstg58cmo/image/upload/v1726209897/ww1_vtnswo.jpg",
    "https://res.cloudinary.com/dstg58cmo/image/upload/v1726209981/w3_hab2b6.jpg"
  ];

  const openModal = (index) => {
    setCurrentImageIndex(index);
    document.getElementById('myModal').style.display = 'block';
  };

  const closeModal = () => {
    document.getElementById('myModal').style.display = 'none';
  };

  const changeImage = (direction) => {
    setCurrentImageIndex((prevIndex) => {
      const newIndex = (prevIndex + direction + images.length) % images.length;
      return newIndex;
    });
  };

  return (
    <div className="gallery-container">
      <h2>Gallery</h2>
      <div className="gallery-grid">
        {images.map((src, index) => (
          <div key={index} className="gallery-item">
            <img 
              src={src} 
              alt={`Gallery ${index + 1}`} 
              onClick={() => openModal(index)} 
            />
          </div>
        ))}
      </div>

      <div id="myModal" className="modal">
        <span className="close" onClick={closeModal}>&times;</span>
        <img className="modal-content" src={images[currentImageIndex]} alt="Modal" />
        <a className="prev" onClick={() => changeImage(-1)}>&#10094;</a>
        <a className="next" onClick={() => changeImage(1)}>&#10095;</a>
      </div>
    </div>
  );
};

export default Gallery;
