// src/components/home/index.js
import React from "react";
import './index.css';

const Home = () => {
  return (
    <>
      {/* Navbar */}
      <nav className="navbar navbar-expand-lg custom-navbar">
        <div className="container-fluid">
          <img src="https://res.cloudinary.com/dstg58cmo/image/upload/v1726211359/aeries_mkxjg9.jpg" className="logo" alt="Logo" />
          <a className="navbar-brand" href="#">Brahmin Sangam Bhavanam</a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav mx-auto">
              <li className="nav-item"><a className="nav-link me-3" href="#home">Home</a></li>
              <li className="nav-item"><a className="nav-link me-3" href="#about">About Us</a></li>
              <li className="nav-item"><a className="nav-link me-3" href="#membership">Membership</a></li>
              <li className="nav-item"><a className="nav-link me-3" href="#gallery">Gallery</a></li>
              <li className="nav-item"><a className="nav-link" href="#contact">Contact Us</a></li>
            </ul>
          </div>
        </div>
      </nav>

      {/* Slideshow */}
      <div id="carouselExample" className="carousel slide" data-bs-ride="carousel">
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src="https://res.cloudinary.com/dstg58cmo/image/upload/v1726209897/ww1_vtnswo.jpg" className="d-block w-100" alt="Bhavanam Image 1" />
          </div>
          <div className="carousel-item">
            <img src="https://res.cloudinary.com/dstg58cmo/image/upload/v1726209981/w3_hab2b6.jpg" className="d-block w-100" alt="Bhavanam Image 2" />
          </div>
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
        </button>
      </div>

      {/* Cards Section */}
      <section className="container mt-5">
        <h2 className="text-center">Our Bhavanam</h2>
        <div className="row text-center">
          <div className="col-md-4">
            <div className="card">
              <img src="https://res.cloudinary.com/dstg58cmo/image/upload/v1726209897/ww1_vtnswo.jpg" className="card-img-top" alt="Image 1" />
              <div className="card-body">
                <h5 className="card-title">Spacious Halls</h5>
                <p className="card-text">Our halls are ideal for large gatherings and events.</p>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card">
              <img src="https://res.cloudinary.com/dstg58cmo/image/upload/v1726209981/w3_hab2b6.jpg" className="card-img-top" alt="Image 2" />
              <div className="card-body">
                <h5 className="card-title">Beautiful Decor</h5>
                <p className="card-text">Elegant interiors designed for all types of events.</p>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card">
              <img src="https://res.cloudinary.com/dstg58cmo/image/upload/v1726209897/ww1_vtnswo.jpg" className="card-img-top" alt="Image 3" />
              <div className="card-body">
                <h5 className="card-title">Convenient Location</h5>
                <p className="card-text">Located in the heart of the city, easily accessible for all.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="custom-footer">
        <div className="container">
          <div className="row">
            <div className="col-md-6">
              <h5>Contact Us</h5>
              <form>
                <div className="mb-3">
                  <label htmlFor="name" className="form-label">Name</label>
                  <input type="text" className="form-control" id="name" placeholder="Your Name" />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email</label>
                  <input type="email" className="form-control" id="email" placeholder="Your Email" />
                </div>
                <div className="mb-3">
                  <label htmlFor="message" className="form-label">Message</label>
                  <textarea className="form-control" id="message" rows="3" placeholder="Your Message"></textarea>
                </div>
                <button type="submit" className="btn btn-primary">Send</button>
              </form>
            </div>
            <div className="col-md-6 text-md-end">
              <h5>Our Address</h5>
              <p>Brahmin Sangam Bhavanam<br />123 Temple Street, City Name<br />State, Country 123456</p>
            </div>
          </div>
          <div className="text-center mt-4">
            <p>© 2024 Brahmin Sangam Bhavanam. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Home;
