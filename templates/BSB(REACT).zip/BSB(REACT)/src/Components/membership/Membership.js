import React from 'react';
import './Membership.css';

const Membership = () => {
  return (
    <section className="container mt-5">
      <h2>Membership</h2>
      <div className="dropdown mb-3">
        <p>Brahmin Sangam Bhavan is a community with 1200+ members. We are dedicated to providing a space for cultural and social gatherings for the Brahmin community. Here, you can explore our facilities and book rooms, which are divided into 3 categories: Gold, Silver, and Platinum.</p>
      </div>

      <table className="table table-striped">
        <thead>
          <tr>
            <th>S.No</th>
            <th>Name</th>
            <th>Number</th>
            <th>Membership Type</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>Carthik</td>
            <td>9099091090</td>
            <td>Gold</td>
          </tr>
          <tr>
            <td>2</td>
            <td>Harsha</td>
            <td>8099091090</td>
            <td>Silver</td>
          </tr>
          <tr>
            <td>3</td>
            <td>Gowtham</td>
            <td>9000000000</td>
            <td>Platinum</td>
          </tr>
          {/* Add more members here */}
        </tbody>
      </table>
    </section>
  );
};

export default Membership;
